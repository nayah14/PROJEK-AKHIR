<?php
include('session.php');
logout();
header("location: login.php");
?>