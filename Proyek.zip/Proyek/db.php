<?php
$conn =new mysqli('localhost','root','','absen_perpekan');